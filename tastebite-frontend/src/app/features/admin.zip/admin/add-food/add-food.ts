import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import {
  Router,
  RouterLink
} from '@angular/router';
import { FoodService } from '../../../core/services/food.service';
@Component({
  selector: 'app-add-food',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink
  ],
  templateUrl: './add-food.html',
  styleUrl: './add-food.css'
})
export class AddFood {

  foodForm: FormGroup;

  selectedFile: File | null = null;
  imagePreview: string | null = null;

  uploadingImage = false;
  submitting = false;

  categories = [
    'Pizza',
    'Burger',
    'Pasta',
    'Indian',
    'Chinese',
    'Dessert',
    'Drinks',
    'Salad'
  ];

  constructor(
    private fb: FormBuilder,
    private foodService: FoodService,
    private router: Router
  ) {

    this.foodForm = this.fb.group({
      name: ['', Validators.required],

      description: [
        '',
        Validators.required
      ],

      price: [
        '',
        [
          Validators.required,
          Validators.min(1)
        ]
      ],

      category: [
        '',
        Validators.required
      ],

      imageUrl: [
        '',
        Validators.required
      ],

      available: [true]
    });
  }

  // Select image
  onFileSelected(event: Event): void {

    const input =
      event.target as HTMLInputElement;

    if (!input.files || input.files.length === 0) {
      return;
    }

    const file = input.files[0];

    this.selectedFile = file;

    // Preview image
    const reader = new FileReader();

    reader.onload = () => {
      this.imagePreview =
        reader.result as string;
    };

    reader.readAsDataURL(file);

    // Upload immediately
    this.uploadImage();
  }

  // Upload image to backend
  uploadImage(): void {

    if (!this.selectedFile) {
      return;
    }

    this.uploadingImage = true;

    this.foodService
      .uploadImage(this.selectedFile)
      .subscribe({

        next: (response: { imageUrl: string }) => {
          this.foodForm.patchValue({
            imageUrl: response.imageUrl
          });

          this.uploadingImage = false;

          console.log(
            'Image uploaded:',
            response.imageUrl
          );
        },

        error: (error: any) => {

          console.error(
            'Image upload failed:',
            error
          );

          this.uploadingImage = false;

          alert(
            'Image upload failed. Please try again.'
          );
        }
      });
  }

  // Create food
  onSubmit(): void {

    if (this.foodForm.invalid) {

      this.foodForm.markAllAsTouched();

      return;
    }

    if (this.uploadingImage) {

      alert(
        'Please wait until image upload is completed.'
      );

      return;
    }

    this.submitting = true;

    this.foodService
      .createFood(this.foodForm.value)
      .subscribe({

        next: () => {

          alert(
            'Food added successfully!'
          );

          this.router.navigate([
            '/admin/foods'
          ]);
        },

        error: (error) => {

          console.error(
            'Create food error:',
            error
          );

          this.submitting = false;

          alert(
            'Failed to add food.'
          );
        }
      });
  }
}