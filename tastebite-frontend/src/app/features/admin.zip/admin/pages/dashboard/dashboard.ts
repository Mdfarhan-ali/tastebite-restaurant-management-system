import { Component, inject, OnInit } from '@angular/core';
import { FoodService } from '../../../../core/services/food.service';
import { OrderService } from '../../../../core/services/order.service';
import { ReservationService } from '../../../../core/services/reservation.service';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-admin-dashboard',
  imports: [RouterLink],
  templateUrl: './dashboard.html'
})
export class AdminDashboard implements OnInit {

  private foodService = inject(FoodService);
  private orderService = inject(OrderService);
  private reservationService = inject(ReservationService);

  totalFoods = 0;
  totalOrders = 0;
  totalReservations = 0;

  loading = true;

  ngOnInit(): void {

    this.foodService.getAllFoods().subscribe({
      next: (foods) => {
        this.totalFoods = foods.length;
      }
    });

    this.orderService.getMyOrders().subscribe({
      next: (orders) => {
        this.totalOrders = orders.length;
      }
    });

    this.reservationService.getMyReservations().subscribe({
      next: (reservations) => {
        this.totalReservations = reservations.length;
        this.loading = false;
      }
    });
  }
}